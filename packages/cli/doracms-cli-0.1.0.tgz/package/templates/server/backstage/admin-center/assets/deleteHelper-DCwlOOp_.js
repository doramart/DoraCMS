import{Y as s}from"./index-C7QNDc5H.js";function m(t,e,n={}){let a,r;return Array.isArray(e)?r=e.join(","):r=String(e),a=`/manage/${t}/${r}`,s({url:a,method:"delete",params:n})}export{m as s};
