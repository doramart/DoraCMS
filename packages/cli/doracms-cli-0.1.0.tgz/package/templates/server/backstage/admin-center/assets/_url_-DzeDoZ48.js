import{d as e,b as n,o}from"./index-C7QNDc5H.js";const m=e({name:"remote-page",__name:"[url]",setup(t){return(a,r)=>(o(),n("div",null," "))}});export{m as default};
